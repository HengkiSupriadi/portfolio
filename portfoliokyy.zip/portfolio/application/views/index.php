<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>Portfolio | Hengki Supriadi</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Edu+TAS+Beginner:wght@400..700&family=Jost:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

        <!-- Icon Font Stylesheet -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

        <!-- Libraries Stylesheet -->
        <link rel="stylesheet" href="lib/animate/animate.min.css"/>
        <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


        <!-- Customized Bootstrap Stylesheet -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="assets/css/style.css" rel="stylesheet">
    </head>

    <body>

        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Navbar Start -->
        <div class="container-fluid nav-section border-0">
            <nav class="navbar navbar-light">
                <div class="navbar-nav flex-column">
                    <a href="#pigraHome" class="nav-item nav-link active"><span class="fa fa-home"></span> Home</a>
                    <a href="#pigraAbout" class="nav-item nav-link"><span class="far fa-address-card"></span> About</a>
                    <a href="#pigraService" class="nav-item nav-link"><span class="fab fa-servicestack"></span> Service</a>
                    <a href="#pigraBlog" class="nav-item nav-link"><span class="fa fa-blog"></span> Blog</a>
                    <a href="#pigraContact" class="nav-item nav-link"><span class="fas fa-address-book"></span> Contact</a>
                </div>
            </nav>
        </div>
        <!-- Navbar End -->

        <!-- Header Start -->
        <div class="container-fluid" id="pigraHome">
            <div class="container">
                <div class="row g-0">
                    <div class="col-12 col-lg-3">
                        <div class="header-content bg-dark h-100 pt-6 pe-6 pb-6">
                            <a href="" class="navbar-brand d-inline-flex pb-5 wow fadeInUp" data-wow-delay="0.1s">
                                <h1 class="display-6 text-white mb-0">Home</h1>
                            </a>
                            <div class="text-start d-flex flex-column justify-content-center wow fadeInUp" data-wow-delay="0.3s">
                                <p class="text-white sub-title"> Hello I'm Hengki Supriadi</p>
                                <h1 class="display-6 text-white mb-0">Creative Designer Based Web in Pontianak</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-9">
                        <div class="header-img d-flex h-100 pt-6 ps-6 pb-6">
                            <div class="row g-5">
                                <div class="col-xl-6 wow fadeInUp" data-wow-delay="0.1s">
                                    <div class="bg-light p-4" style="border-radius: 68% 32% 100% 0% / 0% 75% 25% 100%;">
                                        <img src="assets/img/header-img.jpg" class="img-fluid w-100" style="border-radius: 68% 32% 100% 0% / 0% 75% 25% 100%;" alt="Image">
                                    </div>
                                </div>
                                <div class="col-xl-6 wow fadeInUp" data-wow-delay="0.3s">
                                    <h1 class="display-6 mb-4">Junior UI/UX Designer Developer</h1>
                                    <p class="mb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam sed animi et laboriosam facere tempora rerum, eligendi veritatis nesciunt cum?
                                    </p>
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="fas fa-map-marker-alt text-primary me-3"></i>
                                        <p class="text-dark mb-0">Komp. Star Borneo IV Blok GG.19</p>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="fas fa-envelope text-primary me-3"></i>
                                        <p class="text-dark mb-0">hengkisupriadi9103@gmail.com</p>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="fa fa-phone-alt text-primary me-3"></i>
                                        <p class="text-dark mb-0">+628-134552-0574</p>
                                    </div>
                                    <div class="d-flex">
                                        <a class="btn btn-primary btn-sm-square me-4" href="#"><i class="fab fa-facebook-f text-white"></i></a>
                                        <a class="btn btn-primary btn-sm-square me-4" href="#"><i class="fab fa-whatsapp text-white"></i></a>
                                        <a class="btn btn-primary btn-sm-square me-4" href="#"><i class="fab fa-instagram text-white"></i></a>
                                        <a class="btn btn-primary btn-sm-square me-4" href="#"><i class="fab fa-linkedin-in text-white"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Header End -->


        <!-- About Start -->
        <div class="container-fluid" id="pigraAbout">
            <div class="container">
                <div class="row g-0">
                    <div class="col-12 col-lg-3">
                        <div class="about-header bg-dark h-100 pt-6 pe-6 pb-6">
                            <div class="text-start d-flex flex-column justify-content-center wow fadeInUp" data-wow-delay="0.1s">
                                <p class="text-white sub-title">About Me</p>
                                <h1 class="display-6 text-white mb-0">Senior Designer Web, Pontianak since 2023</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-9">
                        <div class="about-content h-100 pt-6 ps-6 pb-6">
                            <div class="row g-5">
                                <div class="col-xl-5">
                                    <div class="about-img bg-light p-4 wow fadeInUp" data-wow-delay="0.1s">
                                        <img src="img/about.jpg" class="img-fluid w-100" alt="Image">
                                        <div class="sosial-icon">
                                            <a class="btn btn-primary btn-sm-square mb-3" href="#"><i class="fab fa-facebook-f text-white"></i></a>
                                            <a class="btn btn-primary btn-sm-square mb-3" href="#"><i class="fab fa-twitter text-white"></i></a>
                                            <a class="btn btn-primary btn-sm-square mb-3" href="#"><i class="fab fa-instagram text-white"></i></a>
                                            <a class="btn btn-primary btn-sm-square mb-0" href="#"><i class="fab fa-linkedin-in text-white"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-7 wow fadeInUp" data-wow-delay="0.3s">
                                    <h4 class="mb-4">Hello, I'm Hengki Supriadi, Junior Programmer in Pontianak</h4>
                                    <p class="mb-4">Halo! Nama saya Hengki Supriadi, seorang mahasiswa di Politeknik Aisyiyah Pontianak. Saat ini, saya tengah mendalami bidang <b>Teknik Informatika</b>, dan berusaha untuk terus berkembang baik secara akademis maupun profesional.
                                    </p>
                                    <div class="row g-4 mb-4">
                                        <div class="col-6">
                                            <p><strong class="fw-bold text-dark">Nama :</strong>Hengki Supriadi</p>
                                            <p><strong class="fw-bold text-dark">Phone :</strong>+628-134552-0574</p>
                                            <p class="mb-0"><strong class="fw-bold text-dark">Address :</strong>Komp. Star Borneo IV Blok GG.19</p>
                                        </div>
                                        <div class="col-6">
                                            <p><strong class="fw-bold text-dark">Nationality :</strong>Indonesia</p>
                                            <p><strong class="fw-bold text-dark">Email :</strong>hengkisupriadi9103@gmail.com</p>
                                            <p class="mb-0"><strong class="fw-bold text-dark">Freelancer :</strong> Available</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About End -->


        <!-- Education Start -->
        <div class="container-fluid">
            <div class="container">
                <div class="row g-0">
                    <div class="col-lg-3">
                        <div class="education-header bg-dark h-100 pt-6 pe-6 pb-6">
                            <div class="text-start d-flex flex-column justify-content-center wow fadeInUp" data-wow-delay="0.1s">
                                <p class="text-white sub-title">Education</p>
                                <h1 class="display-6 text-white mb-0">My education qualification</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="education-content h-100 pt-6 ps-6 pb-6">
                            <div class="row g-4">
                                <div class="col-12">
                                    <div class="education-item rounded p-4 h-100 wow fadeInUp" data-wow-delay="0.1s">
                                        <div class="d-flex align-items-center mb-3">
                                            <p class="fs-5 mb-0 me-4">National University</p>
                                            <div>
                                                <span class="fa fa-calendar me-1"></span> 2017 - 2019
                                            </div>
                                        </div>
                                        <h4 class="mb-3">Diploma in Computer</h4>
                                        <p class="mb-0">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Corrupti, a quasi velit sint atque non saepe quaerat ducimus, nobis error cupiditate, nisi repudiandae dignissimos magnam? Dicta ab possimus tempora nobis.
                                        </p>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="education-item rounded p-4 h-100 wow fadeInUp" data-wow-delay="0.3s">
                                        <div class="d-flex align-items-center mb-3">
                                            <p class="fs-5 mb-0 me-4">Webster College</p>
                                            <div>
                                                <span class="fa fa-calendar me-1"></span> 2017 - 2019
                                            </div>
                                        </div>
                                        <h4 class="mb-3">UI/UX Design</h4>
                                        <p class="mb-0">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Corrupti, a quasi velit sint atque non saepe quaerat ducimus, nobis error cupiditate, nisi repudiandae dignissimos magnam? Dicta ab possimus tempora nobis.
                                        </p>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="education-item rounded p-4 h-100 wow fadeInUp" data-wow-delay="0.5s">
                                        <div class="d-flex align-items-center mb-3">
                                            <p class="fs-5 mb-0 me-4">Oxford University</p>
                                            <div>
                                                <span class="fa fa-calendar me-1"></span> 2017 - 2019
                                            </div>
                                        </div>
                                        <h4 class="mb-3">Java Development</h4>
                                        <p class="mb-0">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Corrupti, a quasi velit sint atque non saepe quaerat ducimus, nobis error cupiditate, nisi repudiandae dignissimos magnam? Dicta ab possimus tempora nobis.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Education End -->

        <!-- Experience Start -->
        <div class="container-fluid">
            <div class="container">
                <div class="row g-0">
                    <div class="col-lg-3">
                        <div class="experience-header bg-dark h-100 pt-6 pe-6 pb-6">
                            <div class="text-start d-flex flex-column justify-content-center wow fadeInUp" data-wow-delay="0.1s">
                                <p class="text-white sub-title">Experience</p>
                                <h1 class="display-6 text-white mb-0">My real work experience</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="experience-content h-100 pt-6 ps-6 pb-6">
                            <div class="row g-4">
                                <div class="col-12">
                                    <div class="experience-item rounded p-4 h-100 wow fadeInUp" data-wow-delay="0.1s">
                                        <div class="d-flex align-items-center mb-3">
                                            <p class="fs-5 mb-0 me-4">Historian</p>
                                            <div>
                                                <span class="fa fa-calendar me-1"></span> 2017 - 2019
                                            </div>
                                        </div>
                                        <h4 class="mb-3">Seinor UI/UX Desinger</h4>
                                        <p class="mb-0">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Corrupti, a quasi velit sint atque non saepe quaerat ducimus, nobis error cupiditate, nisi repudiandae dignissimos magnam? Dicta ab possimus tempora nobis.
                                        </p>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="experience-item rounded p-4 h-100 wow fadeInUp" data-wow-delay="0.3s">
                                        <div class="d-flex align-items-center mb-3">
                                            <p class="fs-5 mb-0 me-4">Historian</p>
                                            <div>
                                                <span class="fa fa-calendar me-1"></span> 2017 - 2019
                                            </div>
                                        </div>
                                        <h4 class="mb-3">UI/UX Designer</h4>
                                        <p class="mb-0">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Corrupti, a quasi velit sint atque non saepe quaerat ducimus, nobis error cupiditate, nisi repudiandae dignissimos magnam? Dicta ab possimus tempora nobis.
                                        </p>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="experience-item rounded p-4 h-100 wow fadeInUp" data-wow-delay="0.5s">
                                        <div class="d-flex align-items-center mb-3">
                                            <p class="fs-5 mb-0 me-4">Historian</p>
                                            <div>
                                                <span class="fa fa-calendar me-1"></span> 2017 - 2019
                                            </div>
                                        </div>
                                        <h4 class="mb-3">Junior Visual Designer</h4>
                                        <p class="mb-0">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Corrupti, a quasi velit sint atque non saepe quaerat ducimus, nobis error cupiditate, nisi repudiandae dignissimos magnam? Dicta ab possimus tempora nobis.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Exparience End -->


        <!-- Skills Start -->
        <div class="container-fluid">
            <div class="container">
                <div class="row g-0">
                    <div class="col-lg-3">
                        <div class="skills-header h-100 bg-dark pt-6 pe-6 pb-6">
                            <div class="text-start d-flex flex-column justify-content-center wow fadeInUp" data-wow-delay="0.1s">
                                <p class="text-white sub-title">Skills</p>
                                <h1 class="display-6 text-white mb-0">My expertise skills</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="skills-content h-100 pt-6 ps-6 pb-6">
                            <div class="row g-4">
                                <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                    <div class="skills-item text-center rounded p-4 h-100 wow fadeInUp" data-wow-delay="0.1s">
                                        <div class="text-primary text-center mb-3"><span class="fab fa-wordpress fa-3x"></span></div>
                                        <div class="counter-counting d-flex justify-content-center">
                                            <h4 class="display-6" data-toggle="counter-up">98</h4>
                                            <h4 class="display-6">%</h4>
                                        </div>
                                        <p class="mb-0">WordPress</p>
                                    </div>
                                </div>
                                <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                    <div class="skills-item text-center rounded p-4 h-100 wow fadeInUp" data-wow-delay="0.3s">
                                        <div class="text-primary text-center mb-3"><span class="fab fa-figma fa-3x"></span></div>
                                        <div class="counter-counting d-flex justify-content-center">
                                            <h4 class="display-6" data-toggle="counter-up">95</h4>
                                            <h4 class="display-6">%</h4>
                                        </div>
                                        <p class="mb-0">Figma</p>
                                    </div>
                                </div>
                                <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                    <div class="skills-item text-center rounded p-4 h-100 wow fadeInUp" data-wow-delay="0.5s">
                                        <div class="text-primary text-center mb-3"><span class="fab fa-sketch fa-3x"></span></div>
                                        <div class="counter-counting d-flex justify-content-center">
                                            <h4 class="display-6" data-toggle="counter-up">87</h4>
                                            <h4 class="display-6">%</h4>
                                        </div>
                                        <p class="mb-0">Sketch</p>
                                    </div>
                                </div>
                                <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                    <div class="skills-item text-center rounded p-4 h-100 wow fadeInUp" data-wow-delay="0.7s">
                                        <div class="text-primary text-center mb-3"><span class="fab fa-elementor fa-3x"></span></div>
                                        <div class="counter-counting d-flex justify-content-center">
                                            <h4 class="display-6" data-toggle="counter-up">75</h4>
                                            <h4 class="display-6">%</h4>
                                        </div>
                                        <p class="mb-0">Elementor</p>
                                    </div>
                                </div>
                                <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                    <div class="skills-item text-center rounded p-4 h-100 wow fadeInUp" data-wow-delay="0.1s">
                                        <div class="text-primary text-center mb-3"><span class="fab fa-js-square fa-3x"></span></div>
                                        <div class="counter-counting d-flex justify-content-center">
                                            <h4 class="display-6" data-toggle="counter-up">67</h4>
                                            <h4 class="display-6">%</h4>
                                        </div>
                                        <p class="mb-0">JavaScript</p>
                                    </div>
                                </div>
                                <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                    <div class="skills-item text-center rounded p-4 h-100 wow fadeInUp" data-wow-delay="0.3s">
                                        <div class="text-primary text-center mb-3"><span class="fab fa-html5 fa-3x"></span></div>
                                        <div class="counter-counting d-flex justify-content-center">
                                            <h4 class="display-6" data-toggle="counter-up">98</h4>
                                            <h4 class="display-6">%</h4>
                                        </div>
                                        <p class="mb-0">HTML & CSS</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Skills End -->


        <!-- Service Start -->
        <div class="container-fluid" id="pigraService">
            <div class="container">
                <div class="row g-0">
                    <div class="col-lg-3">
                        <div class="service-header h-100 bg-dark pt-6 pe-6 pb-6">
                            <div class="text-start d-flex flex-column justify-content-center wow fadeInUp" data-wow-delay="0.1s">
                                <p class="text-white sub-title">My Services</p>
                                <h1 class="display-6 text-white mb-0">What I do for you</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="service-content h-100 pt-6 ps-6 pb-6">
                            <div class="row g-4">
                                <div class="col-12">
                                    <div class="service-item p-4 wow fadeInUp" data-wow-delay="0.1s">
                                        <div class="row g-4 align-items-center">
                                            <div class="col-xl-2">
                                                <i class="fas fa-bezier-curve fa-3x"></i>
                                            </div>
                                            <div class="col-xl-3">
                                                <a href="#" class="h4 mb-0">Creative Design</a>
                                            </div>
                                            <div class="col-xl-4">
                                                <p class="mb-0">Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis laboriosam repudiandae
                                                </p>
                                            </div>
                                            <div class="col-xl-3">
                                                <p><i class="fa fa-check me-2"></i> UI/UX Design</p>
                                                <p><i class="fa fa-check me-2"></i> Research</p>
                                                <p class="mb-0"><i class="fa fa-check me-2"></i> Mobile App</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="service-item p-4 wow fadeInUp" data-wow-delay="0.3s">
                                        <div class="row g-4 align-items-center">
                                            <div class="col-xl-2">
                                                <i class="fas fa-laptop-code fa-3x"></i>
                                            </div>
                                            <div class="col-xl-3">
                                                <a href="#" class="h4 mb-0">Web Developm</a>
                                            </div>
                                            <div class="col-xl-4">
                                                <p class="mb-0">Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis laboriosam repudiandae
                                                </p>
                                            </div>
                                            <div class="col-xl-3">
                                                <p><i class="fa fa-check me-2"></i> UI/UX Design</p>
                                                <p><i class="fa fa-check me-2"></i> Research</p>
                                                <p class="mb-0"><i class="fa fa-check me-2"></i> Mobile App</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="service-item p-4 wow fadeInUp" data-wow-delay="0.5s">
                                        <div class="row g-4 align-items-center">
                                            <div class="col-xl-2">
                                                <i class="fab fa-app-store fa-3x"></i>
                                            </div>
                                            <div class="col-xl-3">
                                                <a href="#" class="h4 mb-0">Mobile Application</a>
                                            </div>
                                            <div class="col-xl-4">
                                                <p class="mb-0">Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis laboriosam repudiandae
                                                </p>
                                            </div>
                                            <div class="col-xl-3">
                                                <p><i class="fa fa-check me-2"></i> UI/UX Design</p>
                                                <p><i class="fa fa-check me-2"></i> Research</p>
                                                <p class="mb-0"><i class="fa fa-check me-2"></i> Mobile App</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Service End -->


        <!-- Portfolio Start -->
        <div class="container-fluid">
            <div class="container">
                <div class="row g-0">
                    <div class="col-lg-3">
                        <div class="portfolio-header h-100 bg-dark pt-6 pe-6 pb-6">
                            <div class="text-start d-flex flex-column justify-content-center wow fadeInUp" data-wow-delay="0.1s">
                                <p class="text-white sub-title">Portfolio</p>
                                <h1 class="display-6 text-white mb-0">My Recent Works</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="portfolio-content h-100 pt-6 ps-6 pb-6">
                            <div class="portfolio-item py-5 border-bottom wow fadeInUp" data-wow-delay="0.1s">
                                <div class="row g-4 align-items-center">
                                    <div class="col-xl-6">
                                        <h4 class="text-body">Web Design</h4>
                                        <h1 class="display-6 mb-0">Software Design for ABC Corporation</h1>
                                    </div>
                                    <div class="col-9 col-xl-4">
                                        <div class="portfolio-img">
                                            <div class="portfolio-img-inner">
                                                <img src="img/Portfolio-1.jpg" class="img-fluid" alt="Image">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-3 col-xl-2">
                                        <div class="view-img">
                                            <a href="img/Portfolio-1.jpg" class="btn btn-primary btn-lg-square"  data-lightbox="Portfolio-1"><i class="fas fa-plus"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="portfolio-item py-5 border-bottom wow fadeInUp" data-wow-delay="0.3s">
                                <div class="row g-4 align-items-center">
                                    <div class="col-xl-6">
                                        <h4 class="text-body">Web Development</h4>
                                        <h1 class="display-6 mb-0">Website Development for ABC Corporation</h1>
                                    </div>
                                    <div class="col-9 col-xl-4">
                                        <div class="portfolio-img">
                                            <div class="portfolio-img-inner">
                                                <img src="img/portfolio-2.jpg" class="img-fluid" alt="Image">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-3 col-xl-2">
                                        <div class="view-img">
                                            <a href="img/portfolio-2.jpg" class="btn btn-primary btn-lg-square"  data-lightbox="portfolio-2"><i class="fas fa-plus"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="portfolio-item py-5 wow fadeInUp" data-wow-delay="0.5s">
                                <div class="row g-4 align-items-center">
                                    <div class="col-xl-6">
                                        <h4 class="text-body">Photography</h4>
                                        <h1 class="display-6 mb-0">Security Analysis for ABC Corporation</h1>
                                    </div>
                                    <div class="col-9 col-xl-4">
                                        <div class="portfolio-img">
                                            <div class="portfolio-img-inner">
                                                <img src="img/portfolio-3.jpg" class="img-fluid" alt="Image">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-3 col-xl-2">
                                        <div class="view-img">
                                            <a href="img/portfolio-3.jpg" class="btn btn-primary btn-lg-square"  data-lightbox="portfolio-3"><i class="fas fa-plus"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Portfolio End -->


        <!-- Blog Start -->
        <div class="container-fluid" id="pigraBlog">
            <div class="container">
                <div class="row g-0">
                    <div class="col-lg-3">
                        <div class="blog-header h-100 bg-dark pt-6 pe-6 pb-6">
                            <div class="text-start d-flex flex-column justify-content-center wow fadeInUp" data-wow-delay="0.1s">
                                <p class="text-white sub-title">Blog</p>
                                <h1 class="display-6 text-white mb-0">Recent Posts</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="blog-content h-100 pt-6 ps-6 pb-6">
                            <div class="row g-4">
                                <div class="col-xl-6">
                                    <div class="blog-item wow fadeInUp" data-wow-delay="0.1s">
                                        <div class="row g-4">
                                            <div class="col-4">
                                                <div class="blog-item-img bg-dark h-100">
                                                    <a href="#">
                                                        <img src="img/blog-1.jpg" class="img-fluid w-100 h-100" style="object-fit: cover;" alt="Image">
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-8">
                                                <div class="h-100">
                                                    <p class="text-body mb-3"><i class="fa fa-calendar-alt me-2"></i> November 12, 2024</p>
                                                    <a href="#" class="d-inline-block h4 mb-4">Secrets of the Mobile Application</a>
                                                    <div class="py-2 px-3 bg-light d-flex justify-content-between">
                                                        <p class="mb-0 text-body">By <a href="#" class="h6">Bernard</a></p>
                                                        <p class="mb-0 text-body">In <a href="#" class="h6">Design</a></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-6">
                                    <div class="blog-item wow fadeInUp" data-wow-delay="0.3s">
                                        <div class="row g-4">
                                            <div class="col-4">
                                                <div class="blog-item-img bg-dark h-100">
                                                    <a href="#">
                                                        <img src="img/blog-2.jpg" class="img-fluid w-100 h-100" style="object-fit: cover;" alt="Image">
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-8">
                                                <div class="h-100">
                                                    <p class="text-body mb-3"><i class="fa fa-calendar-alt me-2"></i> November 18, 2024</p>
                                                    <a href="#" class="d-inline-block h4 mb-4">How to Create Quality Figma Design</a>
                                                    <div class="py-2 px-3 bg-light d-flex justify-content-between">
                                                        <p class="mb-0 text-body">By <a href="#" class="h6">Walker</a></p>
                                                        <p class="mb-0 text-body">In <a href="#" class="h6">Media</a></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-6">
                                    <div class="blog-item wow fadeInUp" data-wow-delay="0.5s">
                                        <div class="row g-4">
                                            <div class="col-4">
                                                <div class="blog-item-img bg-dark h-100">
                                                    <a href="#">
                                                        <img src="img/blog-3.jpg" class="img-fluid w-100 h-100" style="object-fit: cover;" alt="Image">
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-8">
                                                <div class="h-100">
                                                    <p class="text-body mb-3"><i class="fa fa-calendar-alt me-2"></i> November 23, 2025</p>
                                                    <a href="#" class="d-inline-block h4 mb-4">Tutorials for Learning Development</a>
                                                    <div class="py-2 px-3 bg-light d-flex justify-content-between">
                                                        <p class="mb-0 text-body">By <a href="#" class="h6">Jacob</a></p>
                                                        <p class="mb-0 text-body">In <a href="#" class="h6">Lifestyle</a></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-6">
                                    <div class="blog-item wow fadeInUp" data-wow-delay="0.7s">
                                        <div class="row g-4">
                                            <div class="col-4">
                                                <div class="blog-item-img bg-dark h-100">
                                                    <a href="#">
                                                        <img src="img/blog-4.jpg" class="img-fluid w-100 h-100" style="object-fit: cover;" alt="Image">
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-8">
                                                <div class="h-100">
                                                    <p class="text-body mb-3"><i class="fa fa-calendar-alt me-2"></i> November 26, 2025</p>
                                                    <a href="#" class="d-inline-block h4 mb-4">Tutorials for Learning Development</a>
                                                    <div class="py-2 px-3 bg-light d-flex justify-content-between">
                                                        <p class="mb-0 text-body">By <a href="#" class="h6">Perkel</a></p>
                                                        <p class="mb-0 text-body">In <a href="#" class="h6">Design</a></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 wow fadeInUp" data-wow-delay="0.9s">
                                    <div class="blog-btn d-flex justify-content-center">
                                        <p class="mb-0 me-2">For More Works Visit</p>
                                        <a href="#" class="btn d-inline-block p-0">Our Blog</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Blog End -->


        <!-- Testimonial Start -->
        <div class="container-fluid">
            <div class="container">
                <div class="row g-0">
                    <div class="col-lg-3">
                        <div class="testimonial-header h-100 bg-dark pt-6 pe-6 pb-6">
                            <div class="text-start d-flex flex-column justify-content-center wow fadeInUp" data-wow-delay="0.1s">
                                <p class="text-white sub-title">Testimonial</p>
                                <h1 class="display-6 text-white mb-0">What People Say</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="testimonial-content h-100 pt-6 ps-6 pb-6">
                            <div class="testimonial-carousel owl-carousel bg-light wow fadeInUp" data-wow-delay="0.1s">
                                <div class="testimonial-item" data-dot="<img class='img-fluid' src='img/testimonial-img-1.jpg' alt=''>">
                                    <div class="row gy-4 gx-2 mb-4">
                                        <div class="col-sm-6">
                                            <div class="d-flex justify-content-sm-end">
                                                <div class="testimonial-inner-img border border-primary border-3 me-4" style="width: 100px; height: 100px;">
                                                    <img src="img/testimonial-img-1.jpg" class="img-fluid" style="object-fit: cover;" alt="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div>
                                                <h5 class="mb-2">John Abraham</h5>
                                                <p class="mb-0">New York, USA</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-sm-center">
                                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores nemo facilis tempora esse explicabo sed! Dignissimos quia ullam pariatur blanditiis sed voluptatum. Totam aut quidem laudantium tempora. Minima, saepe earum!
                                        </p>
                                        <div class="d-flex justify-content-sm-center">
                                            <i class="fas fa-star text-primary"></i>
                                            <i class="fas fa-star text-primary"></i>
                                            <i class="fas fa-star text-primary"></i>
                                            <i class="fas fa-star text-primary"></i>
                                            <i class="fas fa-star text-primary"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-item" data-dot="<img class='img-fluid' src='img/testimonial-img-2.jpg' alt=''>">
                                    <div class="row gy-4 gx-2 mb-4">
                                        <div class="col-sm-6">
                                            <div class="d-flex justify-content-sm-end">
                                                <div class="testimonial-inner-img border border-primary border-3 me-4" style="width: 100px; height: 100px;">
                                                    <img src="img/testimonial-img-2.jpg" class="img-fluid" style="object-fit: cover;" alt="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div>
                                                <h5 class="mb-2">John Abraham</h5>
                                                <p class="mb-0">New York, USA</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-sm-center">
                                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores nemo facilis tempora esse explicabo sed! Dignissimos quia ullam pariatur blanditiis sed voluptatum. Totam aut quidem laudantium tempora. Minima, saepe earum!
                                        </p>
                                        <div class="d-flex justify-content-sm-center">
                                            <i class="fas fa-star text-primary"></i>
                                            <i class="fas fa-star text-primary"></i>
                                            <i class="fas fa-star text-primary"></i>
                                            <i class="fas fa-star text-primary"></i>
                                            <i class="fas fa-star text-primary"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-item" data-dot="<img class='img-fluid' src='img/testimonial-img-3.jpg' alt=''>">
                                    <div class="row gy-4 gx-2 mb-4">
                                        <div class="col-sm-6">
                                            <div class="d-flex justify-content-sm-end">
                                                <div class="testimonial-inner-img border border-primary border-3 me-4" style="width: 100px; height: 100px;">
                                                    <img src="img/testimonial-img-3.jpg" class="img-fluid" style="object-fit: cover;" alt="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div>
                                                <h5 class="mb-2">John Abraham</h5>
                                                <p class="mb-0">New York, USA</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-sm-center">
                                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores nemo facilis tempora esse explicabo sed! Dignissimos quia ullam pariatur blanditiis sed voluptatum. Totam aut quidem laudantium tempora. Minima, saepe earum!
                                        </p>
                                        <div class="d-flex justify-content-sm-center">
                                            <i class="fas fa-star text-primary"></i>
                                            <i class="fas fa-star text-primary"></i>
                                            <i class="fas fa-star text-primary"></i>
                                            <i class="fas fa-star text-primary"></i>
                                            <i class="fas fa-star text-primary"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Testimonial End -->


        <!-- Contact Start -->
        <div class="container-fluid" id="pigraContact">
            <div class="container">
                <div class="row g-0">
                    <div class="col-lg-3">
                        <div class="contact-header h-100 bg-dark pt-6 pe-6 pb-6">
                            <div class="text-start d-flex flex-column justify-content-center wow fadeInUp" data-wow-delay="0.1s">
                                <p class="text-white sub-title">Contact Me</p>
                                <h1 class="display-6 text-white mb-0">Let’s Start A New Project</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9">
                       <div class="contact-content h-100 pt-6 ps-6 pb-6">
                            <div class="bg-light p-4">
                                <div class="row g-5">
                                    <div class="col-xl-5 wow fadeInUp" data-wow-delay="0.1s">
                                        <p class="mb-4">The contact form is currently inactive. Get a functional and working contact form with Ajax & PHP in a few minutes. Just copy and paste the files, add a little code and you're done. <a class="text-primary fw-bold" href="https://htmlcodex.com/contact-form">Download Now</a>.</p>
                                        <div class="d-flex mb-4">
                                            <div class="btn-xl-square bg-primary text-white me-3">
                                                <i class="fas fa-map-marker-alt"></i>
                                            </div>
                                            <div>
                                                <h4>Address</h4>
                                                <p class="mb-0">123 Street New York.USA</p>
                                            </div>
                                        </div>
                                        <div class="d-flex mb-4">
                                            <div class="btn-xl-square bg-primary text-white me-3">
                                                <i class="fas fa-envelope"></i>
                                            </div>
                                            <div>
                                                <h4>Mail Us</h4>
                                                <p class="mb-0">info@example.com</p>
                                            </div>
                                        </div>
                                        <div class="d-flex">
                                            <div class="btn-xl-square bg-primary text-white me-3">
                                                <i class="fa fa-phone-alt"></i>
                                            </div>
                                            <div>
                                                <h4>Telephone</h4>
                                                <p class="mb-0">(+012) 3456 7890</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-7 wow fadeInUp" data-wow-delay="0.3s">
                                        <div>
                                            <form>
                                                <div class="row g-3">
                                                    <div class="col-lg-12 col-xl-6">
                                                        <div class="form-floating">
                                                            <input type="text" class="form-control border-0" id="name" placeholder="Your Name">
                                                            <label for="name">Your Name</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12 col-xl-6">
                                                        <div class="form-floating">
                                                            <input type="email" class="form-control border-0" id="email" placeholder="Your Email">
                                                            <label for="email">Your Email</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12 col-xl-6">
                                                        <div class="form-floating">
                                                            <input type="phone" class="form-control border-0" id="phone" placeholder="Phone">
                                                            <label for="phone">Your Phone</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12 col-xl-6">
                                                        <div class="form-floating">
                                                            <input type="text" class="form-control border-0" id="project" placeholder="Project">
                                                            <label for="project">Your Project</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="form-floating">
                                                            <input type="text" class="form-control border-0" id="subject" placeholder="Subject">
                                                            <label for="subject">Subject</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="form-floating">
                                                            <textarea class="form-control border-0" placeholder="Leave a message here" id="message" style="height: 120px"></textarea>
                                                            <label for="message">Message</label>
                                                        </div>
                
                                                    </div>
                                                    <div class="col-12">
                                                        <button class="btn btn-primary w-100 py-3">Send Message</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-12 wow fadeInUp" data-wow-delay="0.5s">
                                        <div class="rounded">
                                            <iframe class="rounded w-100" 
                                            style="height: 400px;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387191.33750346623!2d-73.97968099999999!3d40.6974881!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2sbd!4v1694259649153!5m2!1sen!2sbd" 
                                            loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>
                       </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Contact End -->


        <!-- Footer Start -->
        <div class="container-fluid footer bg-dark border-bottom-0">
            <div class="container wow fadeIn" data-wow-delay="0.1s">
                <div class="row g-0">
                    <div class="col-12">
                       <div class="footer-content h-100 pt-6 ps-6 pb-6">
                            <div class="row g-4 align-items-center">
                                <div class="col-12 text-center">
                                    <div class="d-flex justify-content-center">
                                        <a class="btn btn-light btn-md-square me-3" href=""><i class="fab fa-facebook-f"></i></a>
                                        <a class="btn btn-light btn-md-square me-3" href=""><i class="fab fa-twitter"></i></a>
                                        <a class="btn btn-light btn-md-square me-3" href=""><i class="fab fa-instagram"></i></a>
                                        <a class="btn btn-light btn-md-square me-0" href=""><i class="fab fa-linkedin-in"></i></a>
                                    </div>
                                </div>
                                <div class="col-12 text-center">
                                    <span class="text-body"><a href="#" class="border-bottom text-white"><i class="fas fa-copyright text-body me-2"></i>Your Site Name</a>, All right reserved.</span>
                                </div>
                                <div class="col-12 text-center text-body">
                                    <!--/*** This template is free as long as you keep the below author’s credit link/attribution link/backlink. ***/-->
                                    <!--/*** If you'd like to use the template without the below author’s credit link/attribution link/backlink, ***/-->
                                    <!--/*** you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". ***/-->
                                    Designed By <a class="border-bottom text-white" href="https://htmlcodex.com">HTML Codex</a>
                                </div>
                            </div>
                       </div>        
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-primary btn-lg-square back-to-top"><i class="fa fa-arrow-up"></i></a>   

        
        <!-- JavaScript Libraries -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="assets/lib/wow/wow.min.js"></script>
        <script src="assets/lib/easing/easing.min.js"></script>
        <script src="assets/lib/waypoints/waypoints.min.js"></script>
        <script src="assets/lib/counterup/counterup.min.js"></script>
        <script src="assets/lib/lightbox/js/lightbox.min.js"></script>
        <script src="assets/lib/owlcarousel/owl.carousel.min.js"></script>
        

        <!-- Template Javascript -->
        <script src="assets/js/main.js"></script>
    </body>

</html>